package com.example.spinner

import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.spinner.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var enlace: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enlace = ActivityMainBinding.inflate(layoutInflater)
        setContentView(enlace.root)

        // Configurar adaptadores para los spinners
        val deportes = listOf("", "Fútbol", "Natación", "Atletismo")
        val electivas = listOf("", "Español", "Física", "Matemáticas")
        val hobbies = listOf("", "Nadar", "Bailar", "Comer torta", "Cocinar", "Jardinería")
        val paises = listOf("", "Colombia", "Venezuela", "Perú")

        // Crear y asignar adaptadores
        val adaptadorDeportes = ArrayAdapter(this, R.layout.simple_spinner_dropdown_item, deportes)
        val adaptadorElectivas = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, electivas)
        val adaptadorHobbies = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, hobbies)
        val adaptadorPaises = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, paises)

        // Asignar adaptadores a los spinners
        enlace.spinnerDeporte.adapter = adaptadorDeportes
        enlace.spinnerElectiva.adapter = adaptadorElectivas
        enlace.spinnerHobby.adapter = adaptadorHobbies
        enlace.spinnerPais.adapter = adaptadorPaises

        // Configurar botón enviar
        enlace.btnEnviar.setOnClickListener {
            val intent = Intent(this, ResumenActivity::class.java).apply {
                putExtra("nombre", enlace.editNombre.text.toString())
                putExtra("apellido", enlace.editApellido.text.toString())
                putExtra("celular", enlace.editCelular.text.toString())
                putExtra("deporte", enlace.spinnerDeporte.selectedItem.toString())
                putExtra("electiva", enlace.spinnerElectiva.selectedItem.toString())
                putExtra("hobby", enlace.spinnerHobby.selectedItem.toString())
                putExtra("pais", enlace.spinnerPais.selectedItem.toString())
                putExtra("carrera", enlace.editCarrera.text.toString())
                putExtra("ciudad", enlace.editCiudad.text.toString())
                putExtra("direccion", enlace.editDireccion.text.toString())
            }
            startActivity(intent)
        }
    }
}