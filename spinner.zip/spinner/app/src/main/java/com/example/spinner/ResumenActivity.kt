package com.example.spinner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.spinner.databinding.ActivityResumenBinding

class ResumenActivity : AppCompatActivity() {
    private lateinit var enlace: ActivityResumenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enlace = ActivityResumenBinding.inflate(layoutInflater)
        setContentView(enlace.root)

        // Obtener datos del intent
        intent.extras?.let { extras ->
            val nombre = extras.getString("nombre", "")
            enlace.txtNombre.text = if (nombre.isNotEmpty()) "Nombre: $nombre" else ""
            
            val apellido = extras.getString("apellido", "")
            enlace.txtApellido.text = if (apellido.isNotEmpty()) "Apellido: $apellido" else ""
            
            val celular = extras.getString("celular", "")
            enlace.txtCelular.text = if (celular.isNotEmpty()) "Celular: $celular" else ""
            
            val deporte = extras.getString("deporte", "")
            enlace.txtDeporte.text = if (deporte.isNotEmpty()) "Deporte: $deporte" else ""
            
            val electiva = extras.getString("electiva", "")
            enlace.txtElectiva.text = if (electiva.isNotEmpty()) "Electiva: $electiva" else ""
            
            val hobby = extras.getString("hobby", "")
            enlace.txtHobby.text = if (hobby.isNotEmpty()) "Hobby: $hobby" else ""
            
            val pais = extras.getString("pais", "")
            enlace.txtPais.text = if (pais.isNotEmpty()) "País: $pais" else ""
            
            val carrera = extras.getString("carrera", "")
            enlace.txtCarrera.text = if (carrera.isNotEmpty()) "Carrera: $carrera" else ""
            
            val ciudad = extras.getString("ciudad", "")
            enlace.txtCiudad.text = if (ciudad.isNotEmpty()) "Ciudad: $ciudad" else ""
            
            val direccion = extras.getString("direccion", "")
            enlace.txtDireccion.text = if (direccion.isNotEmpty()) "Dirección: $direccion" else ""
        }

        // Configurar el botón de regreso
        enlace.btnRegresar.setOnClickListener {
            finish()
        }
    }
}